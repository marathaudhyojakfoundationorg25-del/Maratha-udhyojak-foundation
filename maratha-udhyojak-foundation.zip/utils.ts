
import { Member } from './types';

export const exportMembersToCSV = (members: Member[]) => {
  const headers = [
    'ID', 'Name', 'Business Name', 'Category', 'City', 'Email', 'Phone',
    'LinkedIn', 'Twitter', 'Facebook', 'Instagram', 'YouTube', 'Website', 'Bio'
  ];

  const rows = members.map(member => [
    member.id,
    `"${member.name.replace(/"/g, '""')}"`,
    `"${member.businessName.replace(/"/g, '""')}"`,
    `"${member.category.replace(/"/g, '""')}"`,
    `"${member.city.replace(/"/g, '""')}"`,
    member.contact.email,
    member.contact.phone,
    member.socialLinks.linkedin || '',
    member.socialLinks.twitter || '',
    member.socialLinks.facebook || '',
    member.socialLinks.instagram || '',
    member.socialLinks.youtube || '',
    member.socialLinks.website || '',
    `"${member.bio.replace(/"/g, '""')}"`
  ].join(','));

  const csvContent = "data:text/csv;charset=utf-8," 
    + [headers.join(','), ...rows].join('\n');
  
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "maratha_udhyojak_members.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
