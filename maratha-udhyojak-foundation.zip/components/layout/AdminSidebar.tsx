
import React from 'react';
import { NavLink } from 'react-router-dom';

const AdminSidebar = ({ isOpen }: { isOpen: boolean }) => {
  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center p-2 rounded-lg group ${isActive ? 'bg-primary text-primary-foreground' : 'hover:bg-gray-200 dark:hover:bg-gray-700'}`;

  return (
    <aside className={`bg-card text-card-foreground w-64 min-h-screen p-4 border-r border-border transition-transform transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:relative absolute z-40`}>
      <div className="text-2xl font-bold mb-8">MUF Admin</div>
      <nav>
        <ul>
          <li className="mb-2">
            <NavLink to="/admin/dashboard" className={navLinkClass}>Dashboard</NavLink>
          </li>
          <li className="mb-2">
            <NavLink to="/admin/members" className={navLinkClass}>Members</NavLink>
          </li>
          <li className="mb-2">
            <NavLink to="/admin/directors" className={navLinkClass}>Directors</NavLink>
          </li>
          <li className="mb-2">
            <NavLink to="/admin/settings" className={navLinkClass}>Settings</NavLink>
          </li>
          <li className="mb-2">
             <NavLink to="/" className="flex items-center p-2 rounded-lg group hover:bg-gray-200 dark:hover:bg-gray-700">Return to Site</NavLink>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default AdminSidebar;
