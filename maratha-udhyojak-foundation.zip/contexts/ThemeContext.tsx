
import React, { createContext, useContext, useEffect } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { ThemeSettings } from '../types';

const defaultTheme: ThemeSettings = {
  primaryColor: '#f97316', // orange-500
  secondaryColor: '#ea580c', // orange-600
  fontFamily: 'sans',
  mode: 'light',
};

interface ThemeContextType {
  theme: ThemeSettings;
  setTheme: (theme: ThemeSettings) => void;
  toggleMode: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useLocalStorage<ThemeSettings>('theme', defaultTheme);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme.mode);

    const isDark = theme.mode === 'dark';

    root.style.setProperty('--color-primary', theme.primaryColor);
    root.style.setProperty('--color-primary-foreground', isDark ? '#000' : '#fff');
    root.style.setProperty('--color-secondary', theme.secondaryColor);
    root.style.setProperty('--color-secondary-foreground', isDark ? '#000' : '#fff');

    root.style.setProperty('--color-background', isDark ? '#0c0a09' : '#ffffff'); // neutral-950 : white
    root.style.setProperty('--color-foreground', isDark ? '#f2f2f2' : '#171717'); // neutral-100 : neutral-900
    root.style.setProperty('--color-card', isDark ? '#171717' : '#ffffff'); // neutral-900 : white
    root.style.setProperty('--color-card-foreground', isDark ? '#f2f2f2' : '#171717');
    root.style.setProperty('--color-border', isDark ? '#262626' : '#e5e5e5'); // neutral-800 : neutral-200
    
    const font = theme.fontFamily === 'serif' ? 'Georgia, serif' : 'Inter, sans-serif';
    root.style.setProperty('--font-sans', theme.fontFamily === 'sans' ? font : 'Inter, sans-serif');
    root.style.setProperty('--font-serif', theme.fontFamily === 'serif' ? font : 'Georgia, serif');
  }, [theme]);

  const toggleMode = () => {
    setTheme(prevTheme => ({
      ...prevTheme,
      mode: prevTheme.mode === 'light' ? 'dark' : 'light',
    }));
  };
  
  const value = { theme, setTheme, toggleMode };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
