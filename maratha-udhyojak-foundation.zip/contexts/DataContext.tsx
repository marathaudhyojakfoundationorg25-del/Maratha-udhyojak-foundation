
import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Member, Director, PageContent } from '../types';

// Demo data
const initialMembers: Member[] = [
  {
    id: '1',
    name: 'Shivaji Maharaj',
    businessName: 'Swarajya Inc.',
    category: 'Leadership',
    city: 'Raigad',
    contact: { email: 'shivaji@swarajya.com', phone: '123-456-7890' },
    bio: 'Founder of the Maratha Empire, a visionary leader and skilled administrator.',
    photoUrl: 'https://picsum.photos/seed/shivaji/200',
    socialLinks: { linkedin: '#', website: '#', twitter: '#', facebook: '#' }
  },
  {
    id: '2',
    name: 'Sambhaji Maharaj',
    businessName: 'Dakshin Digvijay Co.',
    category: 'Strategy',
    city: 'Pune',
    contact: { email: 'sambhaji@swarajya.com', phone: '123-456-7891' },
    bio: 'A brilliant strategist and scholar, expanded the empire significantly.',
    photoUrl: 'https://picsum.photos/seed/sambhaji/200',
    socialLinks: { linkedin: '#', website: '#' }
  },
    {
    id: '3',
    name: 'Rani Tarabai',
    businessName: 'Maratha Resilience Group',
    category: 'Management',
    city: 'Kolhapur',
    contact: { email: 'tarabai@swarajya.com', phone: '123-456-7892' },
    bio: 'Regent of the Maratha Empire, known for her leadership and resistance against the Mughals.',
    photoUrl: 'https://picsum.photos/seed/tarabai/200',
    socialLinks: { linkedin: '#', website: '#' }
  },
];

const initialDirectors: Director[] = [
  {
    id: 'd1',
    name: 'Tanaji Malusare',
    title: 'Chief Operations Officer',
    description: 'Lead the historic conquest of Kondhana fort. Known for bravery and loyalty.',
    photoUrl: 'https://picsum.photos/seed/tanaji/150'
  },
  {
    id: 'd2',
    name: 'Baji Prabhu Deshpande',
    title: 'Head of Security',
    description: 'A valiant warrior who made a last stand at Ghod Khind to save his king.',
    photoUrl: 'https://picsum.photos/seed/baji/150'
  },
  {
    id: 'd3',
    name: 'Jijabai Shahaji Bhosale',
    title: 'Chairwoman & Mentor',
    description: 'The mother of Shivaji Maharaj, a pillar of strength and a guiding force behind the establishment of Swarajya.',
    photoUrl: 'https://picsum.photos/seed/jijabai/150'
  }
];

const initialContent: PageContent = {
  home: {
    heroTitle: 'Maratha Udhyojak Foundation',
    heroSubtitle: 'Empowering Maratha Entrepreneurs for a Prosperous Future.',
    missionStatement: 'To foster a vibrant ecosystem of entrepreneurship within the Maratha community by providing mentorship, resources, and a platform for growth.'
  },
  about: {
    history: 'Founded in 2023, our organization was born from a collective desire to unite and uplift Maratha entrepreneurs across the globe.',
    vision: 'To be the leading global platform for Maratha entrepreneurs, driving economic growth and innovation.',
    mission: 'Our mission is to connect, educate, and empower Maratha business leaders through networking, mentorship, and access to capital.'
  }
};

interface DataContextType {
  members: Member[];
  addMember: (member: Omit<Member, 'id'>) => void;
  updateMember: (member: Member) => void;
  deleteMember: (id: string) => void;
  directors: Director[];
  addDirector: (director: Omit<Director, 'id'>) => void;
  updateDirector: (director: Director) => void;
  deleteDirector: (id: string) => void;
  content: PageContent;
  setContent: (content: PageContent) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [members, setMembers] = useLocalStorage<Member[]>('members', initialMembers);
  const [directors, setDirectors] = useLocalStorage<Director[]>('directors', initialDirectors);
  const [content, setContent] = useLocalStorage<PageContent>('pageContent', initialContent);

  const generateId = () => new Date().getTime().toString() + Math.random().toString(36).substring(2,9);

  const addMember = (memberData: Omit<Member, 'id'>) => {
    const newMember = { ...memberData, id: generateId() };
    setMembers(prev => [...prev, newMember]);
  };

  const updateMember = (updatedMember: Member) => {
    setMembers(prev => prev.map(m => m.id === updatedMember.id ? updatedMember : m));
  };

  const deleteMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  const addDirector = (directorData: Omit<Director, 'id'>) => {
    const newDirector = { ...directorData, id: generateId() };
    setDirectors(prev => [...prev, newDirector]);
  };

  const updateDirector = (updatedDirector: Director) => {
    setDirectors(prev => prev.map(d => d.id === updatedDirector.id ? updatedDirector : d));
  };

  const deleteDirector = (id: string) => {
    setDirectors(prev => prev.filter(d => d.id !== id));
  };


  const value = {
    members, addMember, updateMember, deleteMember,
    directors, addDirector, updateDirector, deleteDirector,
    content, setContent
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
