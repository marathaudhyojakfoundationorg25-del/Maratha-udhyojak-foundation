
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { DataProvider } from './contexts/DataContext';
import { AuthProvider } from './contexts/AuthContext';

import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';
import ProtectedRoute from './components/ProtectedRoute';

import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import DirectorsPage from './pages/DirectorsPage';
import MembersDirectoryPage from './pages/MembersDirectoryPage';
import MemberProfilePage from './pages/MemberProfilePage';
import NotFoundPage from './pages/NotFoundPage';
import AdminLoginPage from './pages/admin/AdminLoginPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import AdminMembersPage from './pages/admin/AdminMembersPage';
import AdminDirectorsPage from './pages/admin/AdminDirectorsPage';
import AdminSettingsPage from './pages/admin/AdminSettingsPage';

function App() {
  return (
    <ThemeProvider>
      <DataProvider>
        <AuthProvider>
          <HashRouter>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="about" element={<AboutPage />} />
                <Route path="directors" element={<DirectorsPage />} />
                <Route path="members" element={<MembersDirectoryPage />} />
                <Route path="members/:id" element={<MemberProfilePage />} />
              </Route>

              {/* Admin Routes */}
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route 
                path="/admin" 
                element={
                  <ProtectedRoute>
                    <AdminLayout />
                  </ProtectedRoute>
                }
              >
                <Route path="dashboard" element={<AdminDashboardPage />} />
                <Route path="members" element={<AdminMembersPage />} />
                <Route path="directors" element={<AdminDirectorsPage />} />
                <Route path="settings" element={<AdminSettingsPage />} />
              </Route>

              {/* Not Found Route */}
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </HashRouter>
        </AuthProvider>
      </DataProvider>
    </ThemeProvider>
  );
}

export default App;
