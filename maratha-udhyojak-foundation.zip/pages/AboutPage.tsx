
import React from 'react';
import { useData } from '../contexts/DataContext';

const AboutPage = () => {
  const { content } = useData();

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center text-primary">About Us</h1>
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="bg-card p-8 rounded-lg shadow-md border border-border">
          <h2 className="text-2xl font-semibold mb-4">Our History</h2>
          <p className="text-foreground/80 leading-relaxed">{content.about.history}</p>
        </div>
        <div className="bg-card p-8 rounded-lg shadow-md border border-border">
          <h2 className="text-2xl font-semibold mb-4">Our Vision</h2>
          <p className="text-foreground/80 leading-relaxed">{content.about.vision}</p>
        </div>
        <div className="bg-card p-8 rounded-lg shadow-md border border-border">
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-foreground/80 leading-relaxed">{content.about.mission}</p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
