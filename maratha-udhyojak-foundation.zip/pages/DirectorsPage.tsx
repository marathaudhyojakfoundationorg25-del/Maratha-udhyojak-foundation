
import React from 'react';
import { useData } from '../contexts/DataContext';

const DirectorsPage = () => {
    const { directors } = useData();
    return (
        <div className="container mx-auto p-4 md:p-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center text-primary">Director Body</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {directors.map(director => (
                    <div key={director.id} className="bg-card border border-border rounded-lg p-6 text-center shadow-lg">
                        <img src={director.photoUrl} alt={director.name} className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-primary"/>
                        <h2 className="text-xl font-bold text-card-foreground">{director.name}</h2>
                        <h3 className="text-md text-secondary mb-2">{director.title}</h3>
                        <p className="text-foreground/80 text-sm">{director.description}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DirectorsPage;
