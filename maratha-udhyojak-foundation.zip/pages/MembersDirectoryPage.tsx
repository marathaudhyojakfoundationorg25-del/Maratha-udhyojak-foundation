
import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { Link } from 'react-router-dom';

const MembersDirectoryPage = () => {
  const { members } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const categories = useMemo(() => ['All', ...new Set(members.map(m => m.category))], [members]);
  
  const filteredMembers = useMemo(() => {
    return members.filter(member => {
      const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            member.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            member.city.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || member.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [members, searchTerm, categoryFilter]);

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center text-primary">Members Directory</h1>
      
      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <input 
          type="text"
          placeholder="Search by name, business, or city..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full md:w-1/2 p-2 border border-border rounded-md bg-card text-card-foreground"
        />
        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="w-full md:w-1/4 p-2 border border-border rounded-md bg-card text-card-foreground"
        >
          {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
        </select>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredMembers.length > 0 ? filteredMembers.map(member => (
          <div key={member.id} className="bg-card border border-border rounded-lg p-5 shadow-md hover:shadow-xl transition-shadow">
            <img src={member.photoUrl} alt={member.name} className="w-20 h-20 rounded-full mx-auto mb-3" />
            <h2 className="text-lg font-bold text-center text-card-foreground">{member.name}</h2>
            <p className="text-center text-secondary text-sm">{member.businessName}</p>
            <p className="text-center text-xs text-foreground/70 mt-1 mb-3">{member.category} - {member.city}</p>
            <Link to={`/members/${member.id}`} className="block w-full text-center bg-primary text-primary-foreground font-semibold py-2 px-4 rounded-lg hover:bg-secondary transition duration-200">
              View Profile
            </Link>
          </div>
        )) : (
          <p className="col-span-full text-center text-foreground/80">No members found matching your criteria.</p>
        )}
      </div>
    </div>
  );
};

export default MembersDirectoryPage;
