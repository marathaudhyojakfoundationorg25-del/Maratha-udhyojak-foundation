
import React from 'react';
import { useData } from '../contexts/DataContext';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const { content, members } = useData();
  const featuredMembers = members.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-card text-center py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-4">{content.home.heroTitle}</h1>
          <p className="text-lg md:text-xl text-foreground max-w-3xl mx-auto mb-8">{content.home.heroSubtitle}</p>
          <div className="space-x-4">
            <Link to="/members" className="bg-primary text-primary-foreground font-bold py-3 px-8 rounded-lg hover:bg-secondary transition duration-300">View Members</Link>
            <Link to="/about" className="bg-gray-700 text-white font-bold py-3 px-8 rounded-lg hover:bg-gray-600 transition duration-300">Learn More</Link>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="max-w-4xl mx-auto text-lg text-foreground/80">{content.home.missionStatement}</p>
        </div>
      </section>

      {/* Featured Members */}
      <section className="bg-card py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Members</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredMembers.map(member => (
              <div key={member.id} className="bg-background border border-border rounded-lg p-6 text-center shadow-lg transition-transform hover:scale-105">
                <img src={member.photoUrl} alt={member.name} className="w-24 h-24 rounded-full mx-auto mb-4" />
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-primary">{member.businessName}</p>
                <p className="text-sm text-foreground/70 mt-2">{member.category}</p>
                <Link to={`/members/${member.id}`} className="mt-4 inline-block text-secondary hover:underline">View Profile</Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
