
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useData } from '../contexts/DataContext';

const MemberProfilePage = () => {
  const { id } = useParams();
  const { members } = useData();
  const member = members.find(m => m.id === id);

  if (!member) {
    return (
      <div className="text-center p-8">
        <h1 className="text-2xl font-bold">Member not found.</h1>
        <Link to="/members" className="text-primary hover:underline">Back to Directory</Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="max-w-4xl mx-auto bg-card rounded-lg shadow-xl overflow-hidden border border-border">
        <div className="md:flex">
          <div className="md:flex-shrink-0 p-8 flex flex-col items-center justify-center bg-background md:w-1/3">
            <img className="h-48 w-48 rounded-full object-cover border-4 border-primary" src={member.photoUrl} alt={member.name} />
            <h1 className="text-2xl font-bold mt-4 text-center">{member.name}</h1>
            <p className="text-secondary text-center">{member.businessName}</p>
          </div>
          <div className="p-8 flex-1">
            <h2 className="text-xl font-semibold text-primary mb-4 border-b pb-2">Profile Details</h2>
            <div className="space-y-3 text-foreground/90">
                <p><strong>Category:</strong> {member.category}</p>
                <p><strong>City:</strong> {member.city}</p>
                <p><strong>Email:</strong> <a href={`mailto:${member.contact.email}`} className="text-secondary hover:underline">{member.contact.email}</a></p>
                <p><strong>Phone:</strong> {member.contact.phone}</p>
            </div>
            
            <h2 className="text-xl font-semibold text-primary mt-8 mb-4 border-b pb-2">Biography</h2>
            <p className="text-foreground/80 leading-relaxed">{member.bio}</p>

            <h2 className="text-xl font-semibold text-primary mt-8 mb-4 border-b pb-2">Connect</h2>
            <div className="flex space-x-4">
              {Object.entries(member.socialLinks).map(([key, value]) => value && (
                  <a key={key} href={value} target="_blank" rel="noopener noreferrer" className="text-secondary hover:text-primary capitalize">{key}</a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberProfilePage;
