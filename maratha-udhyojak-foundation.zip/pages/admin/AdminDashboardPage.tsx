
import React from 'react';
import { useData } from '../../contexts/DataContext';
import { Link } from 'react-router-dom';

const StatCard = ({ title, value, linkTo }: { title: string, value: number, linkTo: string }) => (
    <Link to={linkTo} className="bg-card p-6 rounded-lg shadow-md border border-border hover:shadow-lg transition-shadow">
        <h2 className="text-lg font-semibold text-foreground/80">{title}</h2>
        <p className="text-3xl font-bold text-primary">{value}</p>
    </Link>
);


const AdminDashboardPage = () => {
    const { members, directors } = useData();

    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Members" value={members.length} linkTo="/admin/members" />
                <StatCard title="Total Directors" value={directors.length} linkTo="/admin/directors" />
                {/* Placeholder for more stats */}
                <div className="bg-card p-6 rounded-lg shadow-md border border-border">
                    <h2 className="text-lg font-semibold text-foreground/80">Quick Actions</h2>
                    <div className="mt-4 space-y-2">
                        <Link to="/admin/members" className="block text-primary hover:underline">Add New Member</Link>
                        <Link to="/admin/directors" className="block text-primary hover:underline">Add New Director</Link>
                        <Link to="/admin/settings" className="block text-primary hover:underline">Customize Site</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboardPage;
