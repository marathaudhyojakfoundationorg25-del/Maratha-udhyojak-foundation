
import React, { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { useData } from '../../contexts/DataContext';

const AdminSettingsPage = () => {
    const { theme, setTheme } = useTheme();
    const { content, setContent } = useData();
    const [pageContent, setPageContent] = useState(content);

    const handleThemeChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setTheme({ ...theme, [name]: value });
    };

    const handleContentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        const [page, field] = name.split('.');
        setPageContent(prev => ({
            ...prev,
            [page]: {
                ...prev[page as keyof typeof prev],
                [field]: value,
            },
        }));
    };

    const saveContent = () => {
        setContent(pageContent);
        alert('Content saved!');
    };

    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Site Settings</h1>

            {/* Theme Settings */}
            <div className="bg-card p-6 rounded-lg shadow-md border border-border mb-8">
                <h2 className="text-xl font-semibold mb-4">Theme Customization</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block mb-1">Primary Color</label>
                        <input type="color" name="primaryColor" value={theme.primaryColor} onChange={handleThemeChange} className="w-full h-10 p-1 border border-border rounded" />
                    </div>
                    <div>
                        <label className="block mb-1">Secondary Color</label>
                        <input type="color" name="secondaryColor" value={theme.secondaryColor} onChange={handleThemeChange} className="w-full h-10 p-1 border border-border rounded" />
                    </div>
                    <div>
                        <label className="block mb-1">Font Family</label>
                        <select name="fontFamily" value={theme.fontFamily} onChange={handleThemeChange} className="w-full p-2 border border-border rounded bg-background">
                            <option value="sans">Sans-serif</option>
                            <option value="serif">Serif</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Content Settings */}
            <div className="bg-card p-6 rounded-lg shadow-md border border-border">
                <h2 className="text-xl font-semibold mb-4">Page Content</h2>
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold border-b border-border pb-2">Home Page</h3>
                    <div>
                        <label className="block mb-1">Hero Title</label>
                        <input type="text" name="home.heroTitle" value={pageContent.home.heroTitle} onChange={handleContentChange} className="w-full p-2 border border-border rounded bg-background" />
                    </div>
                     <div>
                        <label className="block mb-1">Hero Subtitle</label>
                        <textarea name="home.heroSubtitle" value={pageContent.home.heroSubtitle} onChange={handleContentChange} className="w-full p-2 border border-border rounded bg-background" rows={3}></textarea>
                    </div>

                    <h3 className="text-lg font-semibold border-b border-border pb-2 mt-6">About Page</h3>
                     <div>
                        <label className="block mb-1">History</label>
                        <textarea name="about.history" value={pageContent.about.history} onChange={handleContentChange} className="w-full p-2 border border-border rounded bg-background" rows={4}></textarea>
                    </div>
                </div>
                 <button onClick={saveContent} className="mt-6 bg-primary text-primary-foreground font-bold py-2 px-4 rounded hover:bg-secondary">
                    Save Content
                </button>
            </div>
        </div>
    );
};

export default AdminSettingsPage;
