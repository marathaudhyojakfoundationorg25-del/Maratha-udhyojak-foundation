
import React from 'react';
import { useData } from '../../contexts/DataContext';

const AdminDirectorsPage = () => {
    const { directors, deleteDirector } = useData();
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Manage Directors</h1>
                <button onClick={() => alert('Add director form not implemented yet.')} className="bg-primary text-primary-foreground font-bold py-2 px-4 rounded hover:bg-secondary">
                    Add Director
                </button>
            </div>
            <div className="bg-card p-4 rounded-lg shadow-md border border-border">
               <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b border-border">
                                <th className="p-3">Name</th>
                                <th className="p-3">Title</th>
                                <th className="p-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {directors.map(dir => (
                                <tr key={dir.id} className="border-b border-border hover:bg-background">
                                    <td className="p-3">{dir.name}</td>
                                    <td className="p-3">{dir.title}</td>
                                    <td className="p-3">
                                        <button onClick={() => alert('Edit not implemented yet.')} className="text-blue-500 hover:underline mr-4">Edit</button>
                                        <button onClick={() => window.confirm('Are you sure?') && deleteDirector(dir.id)} className="text-red-500 hover:underline">Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminDirectorsPage;
