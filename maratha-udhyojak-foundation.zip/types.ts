
export interface SocialLinks {
  linkedin?: string;
  twitter?: string;
  facebook?: string;
  instagram?: string;
  youtube?: string;
  website?: string;
}

export interface Member {
  id: string;
  name: string;
  businessName: string;
  category: string;
  city: string;
  contact: {
    email: string;
    phone: string;
  };
  bio: string;
  photoUrl: string;
  socialLinks: SocialLinks;
}

export interface Director {
  id: string;
  name:string;
  title: string;
  description: string;
  photoUrl: string;
}

export interface ThemeSettings {
  primaryColor: string;
  secondaryColor: string;
  fontFamily: 'sans' | 'serif';
  mode: 'light' | 'dark';
}

export interface PageContent {
  home: {
    heroTitle: string;
    heroSubtitle: string;
    missionStatement: string;
  };
  about: {
    history: string;
    vision: string;
    mission: string;
  }
}
